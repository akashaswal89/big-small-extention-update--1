chrome.runtime.onInstalled.addListener(() => {
  console.log('Automation Tool Extension Installed');
  
  chrome.storage.local.get(['automationEnabled', 'stats'], (result) => {
    if (result.automationEnabled === undefined) {
      chrome.storage.local.set({ automationEnabled: false });
    }
    if (result.stats === undefined) {
      chrome.storage.local.set({ stats: { actions: 0, startTime: null } });
    }
  });
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'keepAlive') {
    setInterval(() => {
      port.postMessage({ type: 'ping' });
    }, 20000);
  }
});
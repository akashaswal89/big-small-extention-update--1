const toggle = document.getElementById('automationToggle');
const statusBadge = document.getElementById('statusBadge');
const statsSection = document.getElementById('statsSection');
const actionCountEl = document.getElementById('actionCount');
const activeTimeEl = document.getElementById('activeTime');
const refreshBtn = document.getElementById('refreshBtn');
const clearStatsBtn = document.getElementById('clearStatsBtn');
const connectionStatus = document.getElementById('connectionStatus');
const currentUrlEl = document.getElementById('currentUrl');
const autoStatusEl = document.getElementById('autoStatus');

async function loadState() {
  const result = await chrome.storage.local.get(['automationEnabled', 'stats']);
  const isEnabled = result.automationEnabled || false;
  const stats = result.stats || { actions: 0, startTime: null };
  
  toggle.checked = isEnabled;
  updateUI(isEnabled, stats);
}

function updateUI(isEnabled, stats) {
  if (isEnabled) {
    statusBadge.textContent = '● Active';
    statusBadge.classList.add('active');
    statsSection.style.display = 'block';
    autoStatusEl.innerHTML = '🟢 Running';
    connectionStatus.innerHTML = '⚡ Automation Active';
  } else {
    statusBadge.textContent = '○ Inactive';
    statusBadge.classList.remove('active');
    statsSection.style.display = 'none';
    autoStatusEl.innerHTML = '🔴 Stopped';
    connectionStatus.innerHTML = '💤 Automation Stopped';
  }
  
  actionCountEl.textContent = stats.actions || 0;
  
  if (stats.startTime) {
    const elapsed = Math.floor((Date.now() - stats.startTime) / 60000);
    activeTimeEl.textContent = elapsed;
  } else {
    activeTimeEl.textContent = '0';
  }
}

async function saveState(isEnabled) {
  await chrome.storage.local.set({ automationEnabled: isEnabled });
  
  const result = await chrome.storage.local.get(['stats']);
  let stats = result.stats || { actions: 0, startTime: null };
  
  if (isEnabled && !stats.startTime) {
    stats.startTime = Date.now();
  } else if (!isEnabled) {
    stats.startTime = null;
  }
  
  await chrome.storage.local.set({ stats });
  updateUI(isEnabled, stats);
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    try {
      await chrome.tabs.sendMessage(tab.id, { 
        action: 'toggleAutomation', 
        enabled: isEnabled 
      });
      connectionStatus.innerHTML = '✅ Command sent to page';
      setTimeout(() => {
        if (isEnabled) {
          connectionStatus.innerHTML = '⚡ Automation Active';
        } else {
          connectionStatus.innerHTML = '💤 Automation Stopped';
        }
      }, 1500);
    } catch (error) {
      connectionStatus.innerHTML = '⚠️ Refresh the page first';
    }
  }
}

toggle.addEventListener('change', async (e) => {
  await saveState(e.target.checked);
});

refreshBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    connectionStatus.innerHTML = '🔄 Refreshing...';
    await chrome.tabs.reload(tab.id);
    setTimeout(() => {
      connectionStatus.innerHTML = '✅ Page Refreshed';
      setTimeout(() => {
        loadState();
      }, 1000);
    }, 1000);
  }
});

clearStatsBtn.addEventListener('click', async () => {
  await chrome.storage.local.set({ stats: { actions: 0, startTime: null } });
  const result = await chrome.storage.local.get(['automationEnabled']);
  const isEnabled = result.automationEnabled || false;
  await saveState(isEnabled);
  connectionStatus.innerHTML = '📊 Stats Cleared';
  setTimeout(() => {
    if (isEnabled) {
      connectionStatus.innerHTML = '⚡ Automation Active';
    } else {
      connectionStatus.innerHTML = '💤 Automation Stopped';
    }
  }, 1500);
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'updateStats') {
    updateStats(request.stats);
  }
});

async function updateStats(stats) {
  await chrome.storage.local.set({ stats });
  const result = await chrome.storage.local.get(['automationEnabled']);
  updateUI(result.automationEnabled || false, stats);
}

async function getCurrentUrl() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url) {
    const url = new URL(tab.url);
    currentUrlEl.innerHTML = url.hostname;
  }
}

loadState();
getCurrentUrl();
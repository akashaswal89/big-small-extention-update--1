// Automation script - WORKS ON ANY WEBSITE
let automationEnabled = false;
let stats = { actions: 0, startTime: null };
let automationInterval = null;

// Load initial state
async function loadInitialState() {
  const result = await chrome.storage.local.get(['automationEnabled', 'stats']);
  automationEnabled = result.automationEnabled || false;
  stats = result.stats || { actions: 0, startTime: null };
  
  console.log('Auto Tool: Loaded, enabled:', automationEnabled);
  console.log('Current website:', window.location.href);
  
  if (automationEnabled) {
    startAutomation();
  }
}

// ========== 👇👇👇 PUT YOUR CUSTOM LOGIC HERE 👇👇👇 ==========

function performAutomation() {
  if (!automationEnabled) return;
  
  console.log('Auto Tool: Running automation on', window.location.hostname);
  

  function checkTable() {
    const groupA = ['1', '4', '5', '6', '8', '9'];
    const groupB = ['0', '2', '3', '7'];
    
    // Digits that should get GOLDEN color instead of GREEN
    const goldenDigits = ['1', '3', '5', '7', '9'];

    // Helper function to get color (golden for specific digits, else green)
    function getGreenColor(lastDigit) {
      return goldenDigits.includes(lastDigit) ? '#FFD700' : '#0a8f08';
    }

    // =========================
    // Old Table Logic
    // =========================
    document.querySelectorAll('[issuenumber]').forEach(item => {
        const issue = item.getAttribute('issuenumber');
        if (!issue) return;

        const lastDigit = issue.slice(-1);
        const bsText =
            item.querySelector('.t-b2-Num-BS')?.innerText.trim() || '';

        item.style.background = '';

        if (groupA.includes(lastDigit)) {
            if (bsText === 'S') {
                item.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'B') {
                item.style.setProperty('background', '#c40000', 'important');
            }
        }

        if (groupB.includes(lastDigit)) {
            if (bsText === 'B') {
                item.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'S') {
                item.style.setProperty('background', '#c40000', 'important');
            }
        }
    });

    // =========================
    // record-body Logic
    // =========================
    document.querySelectorAll('.record-body .van-row').forEach(row => {
        const issueElement = row.querySelector('.van-col--10');
        const bsElement = row.querySelector('.van-col--5 span');

        if (!issueElement || !bsElement) return;

        const issue = issueElement.innerText.trim();
        const lastDigit = issue.slice(-1);
        const bsText = bsElement.innerText.trim();

        row.style.background = '';

        if (groupA.includes(lastDigit)) {
            if (bsText === 'Small') {
                row.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'Big') {
                row.style.setProperty('background', '#c40000', 'important');
            }
        }

        if (groupB.includes(lastDigit)) {
            if (bsText === 'Big') {
                row.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'Small') {
                row.style.setProperty('background', '#c40000', 'important');
            }
        }
    });

    // =========================
    // GameRecord__C-body Logic
    // =========================
    document.querySelectorAll('.GameRecord__C-body .van-row').forEach(row => {
        const cols = row.querySelectorAll('.van-col');

        if (cols.length < 3) return;

        const issue = cols[0]?.innerText.trim();
        const bsText = cols[2]?.innerText.trim();

        if (!issue || !bsText) return;

        const lastDigit = issue.slice(-1);

        row.style.background = '';

        if (groupA.includes(lastDigit)) {
            if (bsText === 'Small') {
                row.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'Big') {
                row.style.setProperty('background', '#c40000', 'important');
            }
        }

        if (groupB.includes(lastDigit)) {
            if (bsText === 'Big') {
                row.style.setProperty('background', getGreenColor(lastDigit), 'important');
            } else if (bsText === 'Small') {
                row.style.setProperty('background', '#c40000', 'important');
            }
        }
    });
}

// First Run
checkTable();

// Optimized Observer (less lag)
let updateTimer;

const observer = new MutationObserver(() => {
    clearTimeout(updateTimer);
    updateTimer = setTimeout(checkTable, 100);
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

console.log('✅ Color Highlighter Running - Golden for 1,3,5,7,9 instead of Green');
  // DEMO: Shows all buttons on page (remove this and add your code)
  const buttons = document.querySelectorAll('button');
  if (buttons.length > 0) {
    console.log(`Found ${buttons.length} buttons on this page`);
  }
  
  // ========== YOUR CUSTOM CODE ENDS HERE ==========
  
  // Update stats
  stats.actions++;
  chrome.storage.local.set({ stats });
  chrome.runtime.sendMessage({ type: 'updateStats', stats });
}

// ========== 👆👆👆 PUT YOUR CUSTOM LOGIC ABOVE 👆👆👆 ==========

function startAutomation() {
  if (automationInterval) {
    clearInterval(automationInterval);
  }
  
  if (!stats.startTime) {
    stats.startTime = Date.now();
    chrome.storage.local.set({ stats });
  }
  
  // Run automation every 5 seconds (change this value as needed)
  automationInterval = setInterval(() => {
    performAutomation();
  }, 5000);
  
  // Run once immediately
  performAutomation();
  
  console.log('Auto Tool: Started automation on', window.location.hostname);
}

function stopAutomation() {
  if (automationInterval) {
    clearInterval(automationInterval);
    automationInterval = null;
  }
  
  automationEnabled = false;
  stats.startTime = null;
  chrome.storage.local.set({ stats });
  chrome.runtime.sendMessage({ type: 'updateStats', stats });
  
  console.log('Auto Tool: Stopped automation');
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleAutomation') {
    automationEnabled = request.enabled;
    if (automationEnabled) {
      startAutomation();
    } else {
      stopAutomation();
    }
    sendResponse({ success: true });
  }
  return true;
});

// Watch for page navigation (for SPAs)
let lastUrl = location.href;
const navigationObserver = new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log('Auto Tool: Page changed to', url);
    if (automationEnabled) {
      setTimeout(() => {
        performAutomation();
      }, 2000);
    }
  }
});

navigationObserver.observe(document, { subtree: true, childList: true });

// Initialize
loadInitialState();

console.log('Auto Tool: Content script loaded for', window.location.hostname);